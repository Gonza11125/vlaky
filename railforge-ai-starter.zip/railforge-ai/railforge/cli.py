import argparse
from pathlib import Path
import yaml
from .model import Route
from .exporters import export_all


def load_route(path: Path) -> Route:
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    return Route.from_yaml(data)


def main() -> None:
    parser = argparse.ArgumentParser(prog="railforge")
    sub = parser.add_subparsers(dest="command", required=True)

    gen = sub.add_parser("generate", help="Generate route outputs")
    gen.add_argument("route_file", help="Path to route YAML file")
    gen.add_argument("--out", default="output/route", help="Output directory")

    args = parser.parse_args()

    if args.command == "generate":
        route = load_route(Path(args.route_file))
        out_dir = Path(args.out)
        export_all(route, out_dir)
        print(f"Generated RailForge outputs for {route.name} into {out_dir}")
