# Stavební plán: Rokycany - Nezvestice

## Zastávky a stanice

| km | objekt | typ |
|---:|---|---|
| 0.000 | Rokycany | station |
| 1.000 | Rokycany predmesti | stop |
| 3.300 | Kamenny Ujezd u Rokycan | stop |
| 5.000 | Nova Hut | stop |
| 6.600 | Hradek u Rokycan | stop |
| 8.200 | Mirosov | station |
| 9.300 | Mirosov mesto | stop |
| 11.600 | Prikosice zastavka | stop |
| 12.700 | Prikosice | station |
| 15.000 | Mesno | stop |
| 17.200 | Lipnice | stop |
| 19.400 | Kornatice | stop |
| 21.000 | Kornatice rybnik | stop |
| 23.400 | Stahlavice | stop |
| 26.600 | Nezvestice | station |

## Rychlostní profil

| od km | do km | rychlost | poznámka |
|---:|---:|---:|---|
| 0.000 | 8.200 | 80 km/h | Rokycany - Mirosov, needs verification |
| 8.200 | 12.700 | 60 km/h | Mirosov - Prikosice, needs verification |
| 12.700 | 26.600 | 50 km/h | Prikosice - Nezvestice, needs verification |

## Poznámky pro Trainz

- Souřadnice jsou zatím orientační a musí se ověřit podle OSM/TransDEM.
- Další krok: doplnit přejezdy, mosty, návěstidla a přesné kolejiště.
