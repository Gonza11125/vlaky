from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class Stop:
    name: str
    km: float
    lat: float
    lon: float
    type: str

@dataclass(frozen=True)
class SpeedLimit:
    from_km: float
    to_km: float
    speed_kmh: int
    note: str = ""

@dataclass(frozen=True)
class Route:
    id: str
    country: str
    line: str
    public_line: str
    name: str
    stops: list[Stop]
    speed_limits: list[SpeedLimit]

    @staticmethod
    def from_yaml(data: dict[str, Any]) -> "Route":
        meta = data["route"]
        stops = [Stop(**item) for item in data.get("stops", [])]
        speeds = [SpeedLimit(**item) for item in data.get("speed_limits", [])]
        return Route(
            id=str(meta["id"]),
            country=str(meta.get("country", "")),
            line=str(meta.get("line", "")),
            public_line=str(meta.get("public_line", "")),
            name=str(meta.get("name", "")),
            stops=stops,
            speed_limits=speeds,
        )
