from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
ROUTES_DIR = PROJECT_ROOT / "routes"

ROUTE_ALIASES = {
    "175": ROUTES_DIR / "cz_175_p21.yaml",
    "p21": ROUTES_DIR / "cz_175_p21.yaml",
    "cz_175_p21": ROUTES_DIR / "cz_175_p21.yaml",
}


def resolve_route(value: str) -> Path:
    candidate = Path(value)
    if candidate.exists():
        return candidate
    key = value.strip().lower()
    if key in ROUTE_ALIASES:
        return ROUTE_ALIASES[key]
    raise FileNotFoundError(
        f"Unknown route '{value}'. Use a YAML path or one of: {', '.join(sorted(ROUTE_ALIASES))}"
    )
