import csv
import json
from pathlib import Path
from xml.sax.saxutils import escape
from .model import Route


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def export_csv(route: Route, out_dir: Path) -> None:
    with (out_dir / "stops.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["name", "km", "lat", "lon", "type"])
        writer.writeheader()
        for s in route.stops:
            writer.writerow(s.__dict__)

    with (out_dir / "speed_limits.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["from_km", "to_km", "speed_kmh", "note"])
        writer.writeheader()
        for sp in route.speed_limits:
            writer.writerow(sp.__dict__)


def export_geojson(route: Route, out_dir: Path) -> None:
    line_coords = [[s.lon, s.lat] for s in route.stops]
    features = [
        {
            "type": "Feature",
            "properties": {"route": route.id, "name": route.name},
            "geometry": {"type": "LineString", "coordinates": line_coords},
        }
    ]
    for s in route.stops:
        features.append({
            "type": "Feature",
            "properties": {"name": s.name, "km": s.km, "type": s.type},
            "geometry": {"type": "Point", "coordinates": [s.lon, s.lat]},
        })
    geojson = {"type": "FeatureCollection", "features": features}
    (out_dir / "route.geojson").write_text(json.dumps(geojson, ensure_ascii=False, indent=2), encoding="utf-8")


def export_gpx(route: Route, out_dir: Path) -> None:
    trkpts = "\n".join(f'      <trkpt lat="{s.lat}" lon="{s.lon}"><name>{escape(s.name)}</name></trkpt>' for s in route.stops)
    wpts = "\n".join(f'  <wpt lat="{s.lat}" lon="{s.lon}"><name>{escape(s.name)}</name></wpt>' for s in route.stops)
    content = f'''<?xml version="1.0" encoding="UTF-8"?>
<gpx version="1.1" creator="RailForge AI" xmlns="http://www.topografix.com/GPX/1/1">
{wpts}
  <trk><name>{escape(route.name)}</name><trkseg>
{trkpts}
  </trkseg></trk>
</gpx>
'''
    (out_dir / "route.gpx").write_text(content, encoding="utf-8")


def export_kml(route: Route, out_dir: Path) -> None:
    coords = " ".join(f"{s.lon},{s.lat},0" for s in route.stops)
    placemarks = "\n".join(
        f"<Placemark><name>{escape(s.name)}</name><Point><coordinates>{s.lon},{s.lat},0</coordinates></Point></Placemark>"
        for s in route.stops
    )
    content = f'''<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2"><Document>
  <name>{escape(route.name)}</name>
  <Placemark><name>Route axis</name><LineString><coordinates>{coords}</coordinates></LineString></Placemark>
  {placemarks}
</Document></kml>
'''
    (out_dir / "route.kml").write_text(content, encoding="utf-8")


def export_markdown(route: Route, out_dir: Path) -> None:
    rows = ["| km | objekt | typ |", "|---:|---|---|"]
    for s in sorted(route.stops, key=lambda x: x.km):
        rows.append(f"| {s.km:.3f} | {s.name} | {s.type} |")

    speed_rows = ["| od km | do km | rychlost | poznámka |", "|---:|---:|---:|---|"]
    for sp in route.speed_limits:
        speed_rows.append(f"| {sp.from_km:.3f} | {sp.to_km:.3f} | {sp.speed_kmh} km/h | {sp.note} |")

    content = f'''# Stavební plán: {route.name}

## Zastávky a stanice

{chr(10).join(rows)}

## Rychlostní profil

{chr(10).join(speed_rows)}

## Poznámky pro Trainz

- Souřadnice jsou zatím orientační a musí se ověřit podle OSM/TransDEM.
- Další krok: doplnit přejezdy, mosty, návěstidla a přesné kolejiště.
'''
    (out_dir / "build_plan.md").write_text(content, encoding="utf-8")


def export_all(route: Route, out_dir: Path) -> None:
    ensure_dir(out_dir)
    export_csv(route, out_dir)
    export_geojson(route, out_dir)
    export_gpx(route, out_dir)
    export_kml(route, out_dir)
    export_markdown(route, out_dir)
