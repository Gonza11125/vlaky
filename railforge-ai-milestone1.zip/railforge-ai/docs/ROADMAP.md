# Roadmap

## v0.1
- Ruční definice tratě 175.
- Export GPX/KML/GeoJSON/CSV/Markdown.

## v0.2
- Overpass API klient.
- Stažení OSM prvků v okolí tratě.

## v0.3
- Rozdělení vrstev: koleje, silnice, budovy, voda, lesy.

## v0.4
- Přejezdy, mosty, propustky.

## v0.5
- Railway Engine: kilometráž a objekty podél tratě.

## v1.0
- Praktický workflow pro TransDEM + Trainz Surveyor.
