# RailForge AI

RailForge AI je startovní open-source projekt pro generování podkladů železničních tratí pro Trainz / TransDEM.

První testovací trať: **175 Rokycany – Nezvěstice (linka P21)**.

## Co tato první verze umí

- načte ručně připravenou databázi zastávek tratě 175,
- načte rychlostní profil,
- spočítá jednoduchou kilometrážní osu,
- vygeneruje výstupy:
  - GPX,
  - KML,
  - GeoJSON,
  - CSV,
  - Markdown stavební plán.

Toto není hotový export do Trainzu. Je to základ skutečného repozitáře, na kterém se dá dál stavět.

## Instalace

```bash
cd railforge-ai
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -e .
```

## Použití

```bash
railforge generate routes/cz_175_p21.yaml --out output/p21
```

Výstupy najdeš v:

```text
output/p21/
```

## Struktura

```text
railforge-ai/
  railforge/          # Python balíček
  routes/             # definice tratí
  docs/               # dokumentace
  output/             # generované výstupy
  pyproject.toml
  README.md
```

## Další cíle

- v0.2: stahování OSM přes Overpass API,
- v0.3: rozdělené GeoJSON vrstvy,
- v0.4: přejezdy, mosty, budovy,
- v0.5: kilometrážní engine,
- v1.0: použitelný workflow RailForge → TransDEM → Trainz.
