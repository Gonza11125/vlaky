from pathlib import Path
from railforge.cli import load_route
from railforge.routes import resolve_route


def test_resolve_route_alias_175():
    path = resolve_route("175")
    assert path.name == "cz_175_p21.yaml"
    assert path.exists()


def test_load_route_175_has_all_stops():
    route = load_route(resolve_route("175"))
    assert route.line == "175"
    assert route.public_line == "P21"
    assert len(route.stops) == 15
    assert route.stops[0].name == "Rokycany"
    assert route.stops[-1].name == "Nezvestice"


def test_speed_profile_covers_route():
    route = load_route(resolve_route("175"))
    assert route.speed_limits[0].from_km == 0.0
    assert route.speed_limits[-1].to_km == 26.6
