from pathlib import Path
from railforge.cli import load_route
from railforge.exporters import export_all
from railforge.routes import resolve_route


def test_export_all_creates_expected_files(tmp_path: Path):
    route = load_route(resolve_route("175"))
    export_all(route, tmp_path)

    expected = {
        "stops.csv",
        "speed_limits.csv",
        "route.geojson",
        "route.gpx",
        "route.kml",
        "build_plan.md",
    }
    assert expected.issubset({p.name for p in tmp_path.iterdir()})
    assert "Kornatice" in (tmp_path / "build_plan.md").read_text(encoding="utf-8")
