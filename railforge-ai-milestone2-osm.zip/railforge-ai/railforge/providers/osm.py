from __future__ import annotations

import json
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from railforge.model import Route

OVERPASS_URL = "https://overpass-api.de/api/interpreter"


@dataclass(frozen=True)
class BoundingBox:
    south: float
    west: float
    north: float
    east: float

    def to_overpass(self) -> str:
        return f"{self.south:.6f},{self.west:.6f},{self.north:.6f},{self.east:.6f}"


def route_bbox(route: Route, padding_deg: float = 0.025) -> BoundingBox:
    """Return a simple padded bounding box around route stops."""
    if not route.stops:
        raise ValueError("Route has no stops, cannot build OSM bounding box")

    lats = [s.lat for s in route.stops]
    lons = [s.lon for s in route.stops]
    return BoundingBox(
        south=min(lats) - padding_deg,
        west=min(lons) - padding_deg,
        north=max(lats) + padding_deg,
        east=max(lons) + padding_deg,
    )


def build_overpass_query(route: Route, padding_deg: float = 0.025) -> str:
    """Build Overpass QL query for railway and nearby map features."""
    bbox = route_bbox(route, padding_deg).to_overpass()
    return f"""
[out:json][timeout:90];
(
  way["railway"]({bbox});
  node["railway"]({bbox});
  way["highway"]({bbox});
  way["building"]({bbox});
  way["natural"="water"]({bbox});
  way["waterway"]({bbox});
  way["landuse"="forest"]({bbox});
  way["natural"="wood"]({bbox});
  node["railway"="level_crossing"]({bbox});
  node["railway"="signal"]({bbox});
);
out body;
>;
out skel qt;
""".strip()


def fetch_overpass(query: str, url: str = OVERPASS_URL, timeout: int = 120) -> dict[str, Any]:
    """Fetch raw Overpass JSON using only Python stdlib."""
    data = urllib.parse.urlencode({"data": query}).encode("utf-8")
    request = urllib.request.Request(url, data=data, headers={"User-Agent": "RailForgeAI/0.2"})
    with urllib.request.urlopen(request, timeout=timeout) as response:  # nosec: user-selected API URL
        return json.loads(response.read().decode("utf-8"))


def save_raw_osm(data: dict[str, Any], out_dir: Path) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / "osm_raw.json"
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def _node_lookup(elements: Iterable[dict[str, Any]]) -> dict[int, tuple[float, float]]:
    nodes: dict[int, tuple[float, float]] = {}
    for element in elements:
        if element.get("type") == "node" and "lat" in element and "lon" in element:
            nodes[int(element["id"])] = (float(element["lon"]), float(element["lat"]))
    return nodes


def _category(tags: dict[str, Any]) -> str:
    railway = tags.get("railway")
    if railway == "level_crossing":
        return "crossings"
    if railway == "signal":
        return "signals"
    if railway:
        return "railway"
    if "highway" in tags:
        return "roads"
    if "building" in tags:
        return "buildings"
    if tags.get("natural") in {"water", "wood"} or "waterway" in tags or tags.get("landuse") == "forest":
        if tags.get("landuse") == "forest" or tags.get("natural") == "wood":
            return "forests"
        return "water"
    return "other"


def overpass_to_feature_collections(data: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Convert a useful subset of Overpass JSON into GeoJSON FeatureCollections."""
    elements = data.get("elements", [])
    nodes = _node_lookup(elements)
    layers: dict[str, list[dict[str, Any]]] = {
        "railway": [],
        "stations": [],
        "crossings": [],
        "signals": [],
        "roads": [],
        "buildings": [],
        "water": [],
        "forests": [],
        "other": [],
    }

    for element in elements:
        tags = element.get("tags", {}) or {}
        if element.get("type") == "node" and "lat" in element and "lon" in element:
            cat = _category(tags)
            if tags.get("railway") in {"station", "halt", "stop", "tram_stop"}:
                cat = "stations"
            if cat in {"other", "railway"} and not tags:
                continue
            layers.setdefault(cat, []).append({
                "type": "Feature",
                "properties": {"osm_id": element.get("id"), "osm_type": "node", **tags},
                "geometry": {"type": "Point", "coordinates": [element["lon"], element["lat"]]},
            })
            continue

        if element.get("type") == "way" and element.get("nodes"):
            coords = [nodes[node_id] for node_id in element["nodes"] if node_id in nodes]
            if len(coords) < 2:
                continue
            cat = _category(tags)
            closed = coords[0] == coords[-1] and cat in {"buildings", "water", "forests"}
            geometry = {
                "type": "Polygon" if closed else "LineString",
                "coordinates": [coords] if closed else coords,
            }
            layers.setdefault(cat, []).append({
                "type": "Feature",
                "properties": {"osm_id": element.get("id"), "osm_type": "way", **tags},
                "geometry": geometry,
            })

    return {name: {"type": "FeatureCollection", "features": features} for name, features in layers.items()}


def write_feature_collections(collections: dict[str, dict[str, Any]], out_dir: Path) -> list[Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []
    for name, collection in collections.items():
        if not collection.get("features"):
            continue
        path = out_dir / f"{name}.geojson"
        path.write_text(json.dumps(collection, ensure_ascii=False, indent=2), encoding="utf-8")
        written.append(path)
    return written


def write_osm_summary(collections: dict[str, dict[str, Any]], out_dir: Path) -> Path:
    summary = {name: len(collection.get("features", [])) for name, collection in sorted(collections.items())}
    path = out_dir / "osm_summary.json"
    path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return path
