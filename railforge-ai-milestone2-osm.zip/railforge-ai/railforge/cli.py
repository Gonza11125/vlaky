import argparse
from pathlib import Path
import yaml
from .model import Route
from .exporters import export_all
from .routes import resolve_route


def load_route(path: Path) -> Route:
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    return Route.from_yaml(data)


def main() -> None:
    parser = argparse.ArgumentParser(prog="railforge")
    sub = parser.add_subparsers(dest="command", required=True)

    gen = sub.add_parser("generate", help="Generate route outputs")
    gen.add_argument("route", help="Route number/alias, e.g. 175 or p21, or path to route YAML")
    gen.add_argument("--out", default="output/route", help="Output directory")
    gen.add_argument("--fetch-osm", action="store_true", help="Download OSM/Overpass data and export map layers")
    gen.add_argument("--osm-padding", type=float, default=0.025, help="BBox padding in degrees for OSM download")

    args = parser.parse_args()

    if args.command == "generate":
        route_file = resolve_route(args.route)
        route = load_route(route_file)
        out_dir = Path(args.out)
        export_all(route, out_dir)
        if args.fetch_osm:
            from .providers.osm import (
                build_overpass_query,
                fetch_overpass,
                overpass_to_feature_collections,
                save_raw_osm,
                write_feature_collections,
                write_osm_summary,
            )

            query = build_overpass_query(route, padding_deg=args.osm_padding)
            (out_dir / "overpass_query.ql").write_text(query, encoding="utf-8")
            raw = fetch_overpass(query)
            save_raw_osm(raw, out_dir)
            collections = overpass_to_feature_collections(raw)
            write_feature_collections(collections, out_dir)
            write_osm_summary(collections, out_dir)
        print(f"Generated RailForge outputs for {route.name} into {out_dir}")


if __name__ == "__main__":
    main()
