from railforge.providers.osm import build_overpass_query, overpass_to_feature_collections, route_bbox
from railforge.routes import resolve_route
from railforge.cli import load_route


def test_route_bbox_contains_p21():
    route = load_route(resolve_route("175"))
    bbox = route_bbox(route, padding_deg=0.0)
    assert bbox.south < bbox.north
    assert bbox.west < bbox.east
    assert 49.55 < bbox.south < 49.65
    assert 49.70 < bbox.north < 49.80
    assert bbox.west < 13.7 < bbox.east


def test_overpass_query_mentions_core_layers():
    route = load_route(resolve_route("p21"))
    query = build_overpass_query(route)
    assert '["railway"]' in query
    assert '["highway"]' in query
    assert '["building"]' in query
    assert "level_crossing" in query


def test_overpass_to_geojson_layers():
    data = {
        "elements": [
            {"type": "node", "id": 1, "lat": 49.742, "lon": 13.594},
            {"type": "node", "id": 2, "lat": 49.743, "lon": 13.595, "tags": {"railway": "level_crossing"}},
            {"type": "way", "id": 10, "nodes": [1, 2], "tags": {"railway": "rail"}},
        ]
    }
    collections = overpass_to_feature_collections(data)
    assert len(collections["railway"]["features"]) == 1
    assert len(collections["crossings"]["features"]) == 1
