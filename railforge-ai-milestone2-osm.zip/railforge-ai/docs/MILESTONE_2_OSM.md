# Milestone 2: OSM / Overpass provider

Tato verze přidává první skutečný datový provider pro OpenStreetMap přes Overpass API.

## Použití

Základní export jako dřív:

```bash
railforge generate 175 --out output/p21
```

Export + stažení OSM vrstev:

```bash
railforge generate 175 --out output/p21 --fetch-osm
```

Volitelně lze upravit velikost oblasti kolem zastávek:

```bash
railforge generate 175 --out output/p21 --fetch-osm --osm-padding 0.03
```

## Nové výstupy

Při `--fetch-osm` vzniknou navíc:

- `overpass_query.ql` – použitý Overpass dotaz
- `osm_raw.json` – surová odpověď z Overpass API
- `railway.geojson`
- `stations.geojson`
- `crossings.geojson`
- `signals.geojson`
- `roads.geojson`
- `buildings.geojson`
- `water.geojson`
- `forests.geojson`
- `osm_summary.json`

## Poznámky

Provider zatím používá bounding box kolem zastávek. Další krok bude přesnější výběr prvků podle vzdálenosti od osy tratě a výpočet jejich kilometráže.
